

const en = {
  "Home": "Home",
  "welcome": "Welcome to my website!",

  "about": "About",
    "Doctors": "doctors",
  "contact": "Contact",
  // add more keys and values as needed
};
