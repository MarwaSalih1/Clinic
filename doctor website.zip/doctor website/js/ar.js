const ar = {
  "greeting": "مرحبا",
  "welcome": "Bienvenue sur mon site web!",
  "about": "عن ",
  "contact": "تواصل معنا",
  "Home": "الصفحة الرئيسية",
  // add more keys and values as needed
};